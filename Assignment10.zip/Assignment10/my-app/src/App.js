import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import WeatherForecast from "./components/WeatherForecast.js";
import DayForecast from "./components/DayForecast.js";

const App = () => {
  return (
    <Router>
      <div>
        <Routes>
          <Route exact path="/" element={<WeatherForecast/>}>
          </Route>
          <Route path="/:day" element={<DayForecast/>}>
          </Route>
        </Routes>
      </div>
    </Router>
  );
};

export default App;
