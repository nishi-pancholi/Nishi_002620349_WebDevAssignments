import React, { useState, useEffect } from "react";
import {  Link} from "react-router-dom";

import "./WeatherForecast.css";

const WeatherForecast = () => {
  const [weatherData, setWeatherData] = useState([]);

  useEffect(() => {
    // fetch data from OpenWeatherMap API
    const apiKey = "4bb5e111d80c3d2a5c6a42696dc14f19";
    const apiUrl = `https://api.openweathermap.org/data/2.5/forecast?q=New+York&appid=${apiKey}&units=imperial`;

    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        const dailyData = [];
        data.list.forEach((item) => {
          const date = new Date(item.dt * 1000).toLocaleDateString("en-US", {
            weekday: "long",
            month: "short",
            day: "numeric",
          });
          const existingDay = dailyData.find((day) => day.date === date);
          if (existingDay) {
            if (item.main.temp_max > existingDay.high) {
              existingDay.high = item.main.temp_max;
            }
            if (item.main.temp_min < existingDay.low) {
              existingDay.low = item.main.temp_min;
            }
            existingDay.conditions.push(item.weather[0].main);
          } else {
            dailyData.push({
              date: date,
              high: item.main.temp_max,
              low: item.main.temp_min,
              conditions: [item.weather[0].icon],
            });
          }
        });
        setWeatherData(dailyData);
      });
  }, []);
  console.log(weatherData);
  return (
    <div>
      <h1>5-Day Weather Forecast</h1>
      <div className="weather-forecast">
        {weatherData.map((day) => (
          
            <div className="weather-card">
              <Link to={`/${day.date}`} key={day.date}>
                <h2>{day.date}</h2>
              </Link>
              <img
                src={`http://openweathermap.org/img/w/${day.conditions[0]}.png`}
                alt={day.conditions[0]}
              />
              <div className="temps">
                <span className="high">Highest:{day.high}&deg;F</span>
                <span className="low">Lowest:{day.low}&deg;F</span>
              </div>
            </div>
        ))}
      </div>
    </div>
  );
};

export default WeatherForecast;
