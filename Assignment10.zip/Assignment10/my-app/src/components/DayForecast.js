import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import './DayForecast.css';


const DayForecast = () => {
  const { day } = useParams();
  const [hourlyData, setHourlyData] = useState([]);

  useEffect(() => {
    // fetch data from OpenWeatherMap API
    const apiKey = "4bb5e111d80c3d2a5c6a42696dc14f19";
    const apiUrl = `https://api.openweathermap.org/data/2.5/forecast?q=New+York&appid=${apiKey}&units=imperial`;
    

    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        const hourlyData = data.list.filter(
          (item) =>
            new Date(item.dt * 1000).toLocaleDateString("en-US", {
              weekday: "long",
              month: "short",
              day: "numeric",
            }) === day
        );
        setHourlyData(hourlyData);
      });
  }, [day]);

  return (
    <div>
      <h2>Hourly forecast for {day}</h2>
      <div className="hourly-forecast">
        {hourlyData.map((item) => (
          <div className="hourly-card" key={item.dt}>
            <p>{new Date(item.dt * 1000).toLocaleTimeString()}</p>
            <img
              src={`http://openweathermap.org/img/w/${item.weather[0].icon}.png`}
              alt={item.weather[0].main}
            />
            <p>{item.main.temp}&deg;F</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DayForecast;
