This is a website for assignment 2.
This is a rprofile portfolio website. It is a basic html/css based website.

In this website, there are 3 webpages:
-> 'index.html' which is the profile webpage.
In this webpage, there are tags like header,footer,nav,div,link,img.
There is a CSS property used for BackgroundImage throughout the website.
It consists of coloumn layout structure. The icons on click will land up to connecting social media handles.

->'services.html' which is the page to know about the restaurant.
The description is given with a font-family of fantasy and a standard of fonts is maintained throughout the website.
The cards show a font-awesome icon and details.

->'certifications.html' is the last page of the website that can be used to submit the form print.
There are images in the card which are designed to show the details on hover.

In this webpage, there are some icons for phone, email,linkedin,github in order to make the profile reachable.
these Icons arew taken from a FontAwesome lib in ajax 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'.

->'external.css' is an external Stylesheet used to style throughout the website.
This CSS file containes of styling done throughout the webpage using (asterix \*).
It includes styling done through class as well as id.
It also includes styling done through tags.
This website follows a theme of fonts and colours throughout for better User Experience.
The Profile image has a backdrop shadow.
Text has shadows.
The certifications gallery has cards which contain images and has a caption which on hover displays the content.
The @media queries helps the text and content of the webpage to be responsive.

This Website includes header and footer on everywebpage with the position being fixed.
The footer consists position being relative.

The Images used in the website are used from a copyright free website from 'www.google.com'.

Tags Used In this Website are:

header
footer
nav
anchor HyperLink
img
FavIcon
Font Awesome Icon
background Image


CSS based properties:
hover
media
transition
position
float
overflow
box-sizing
content 
margin
padding



