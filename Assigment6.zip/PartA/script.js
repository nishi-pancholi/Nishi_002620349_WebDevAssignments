function displayError(message) {
    $("#error").text(message);
}

function clearError() {
    $("#error").text("");
}

function Operation(operand) {
    const number1 = $("#firstNumber").val().trim();
    const number2  = $("#secondNumber").val().trim();
    if (number1 === "" || isNaN(number1)) {
        displayError("Number 1 should be a numeric value");
    } else if (number2 === "" || isNaN(number2)) {
        displayError("Number 2 should be a numeric value");
    } else {
        clearError();
        const firstValue= parseInt(number1);
        const secondValue=parseInt(number2);
        var result = 0;
        switch (operand) {
        case "+":
            result = ((x, y) => {
            return x + y;
            })(firstValue, secondValue);
            break;

        case "-":
            result = ((x, y) => {
            return x - y;
            })(firstValue, secondValue);
            break;
        case "*":
            result = ((x, y) => {
            return x * y;
            })(firstValue, secondValue);
            break;
        case "/":
            result = ((x, y) => {
            return y === 0 ? "Infinity" : x / y;
            })(firstValue, secondValue);
            break;
        default:
            return 0;
        }
        document.getElementById("result").setAttribute("value",result);
    }
  }

  var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
    return false;
};

