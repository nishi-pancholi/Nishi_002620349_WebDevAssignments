const display = document.getElementById("display");
const startButton = document.getElementById("start");
const stopButton = document.getElementById("stop");
const resetButton = document.getElementById("reset");

let seconds = 0;
let minutes = 0;
let hours = 0;

let interval;

async function startTimer() {
    interval = setInterval(() => {
        seconds++;
        if (seconds === 60) {
            seconds = 0;
            minutes++;
            if (minutes === 60) {
                minutes = 0;
                hours++;
            }
        }
        displayTime();
    }, 1000);
    startButton.disabled = true;
    await new Promise(resolve => setTimeout(resolve, 0));
    stopButton.disabled = false;
    resetButton.disabled = false;
}

function stopTimer() {
    clearInterval(interval);
    stopButton.disabled = true;
    startButton.disabled = false;
}

function resetTimer() {
    clearInterval(interval);
    seconds = 0;
    minutes = 0;
    hours = 0;
    displayTime();
    stopButton.disabled = true;
    resetButton.disabled = true;
    startButton.disabled = false;
}




function displayTime() {
    let sec = seconds < 10 ? `0${seconds}` : seconds;
    let min = minutes < 10 ? `0${minutes}` : minutes;
    let hr = hours < 10 ? `0${hours}` : hours;
    display.textContent = `${hr}:${min}:${sec}`;
}

startButton.addEventListener("click", async () => {
    await startTimer();
});

stopButton.addEventListener("click", () => {
    stopTimer();
});

resetButton.addEventListener("click", () => {
    resetTimer();
});



