const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
var cors = require('cors');
var bodyParser = require("body-parser");
var methodOverride = require("method-override");

const app = express();

mongoose.connect('mongodb://localhost:27017/users', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});


app.listen(3000, () => {
    console.log('Server started on port 3000');
});

mongoose.connection.on('error', function (err) {
    console.log('database connection error');
    console.log(err)
}); 

mongoose.connection.on('open', function (err) {
    if (err) {
        console.log("database error");
        console.log(err);
    } else {
        console.log("database connection open success");
    }
});

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.json({ type: "application/vnd.api+json" }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride("X-HTTP-Method-Override"));
app.use(express.static(__dirname + "/public"));


const userSchema = new mongoose.Schema({
  fullName: {
    type: String,
    validate: /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/,
    required: true,
  },
  email: {
    type: String,
    validate: /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    minlength: 8,
    required: true,
  },
});

const User = mongoose.model('User', userSchema);

app.post('/user/create', async (req, res) => {
    console.log(req.body.email);
    console.log(req.body.fullName);
    console.log(req.body.password);
    const fullName= req.body.fullName;
    const email= req.body.email;
    const password=req.body.password;

  if (!fullName || !email || !password) {
    return res.status(400).send({ message: 'Please provide full name, email, and password' });
  }

  if (!email.match(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/)) {
    return res.status(400).send({ message: 'Invalid email format' });
  }

  if (!fullName.match(/^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/)) {
    return res.status(400).send({ message: 'Invalid full name format' });
  }

  if (!password.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)) {
    return res.status(400).send({ message: 'Invalid password format. Sorry, password requires at least 8 characters,one uppercase letter, one lowercase letter, one number and one special character.' });
  }


  const saltRounds = 10;
  const hashedPassword = await bcrypt.hash(password, saltRounds);


  const user = new User({ fullName, email, password: hashedPassword });

  try {
    await user.save();
    res.send({ message: 'User created successfully' });
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
});


app.put('/user/edit', async (req, res) => {
  const { email, fullName, password } = req.body;


  if (!email || !fullName || !password) {
    return res.status(400).send({ message: 'Please provide email, full name, and password' });
  }

  if (!fullName.match(/^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/)) {
    return res.status(400).send({ message: 'Invalid full name format' });
  }

  if (!password.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)) {
    return res.status(400).send({ message: 'Invalid password format.Sorry, password requires at least 8 characters,one uppercase letter, one lowercase letter, one number and one special character.' });
  }


  const saltRounds = 10;
  const hashedPassword = await bcrypt.hash(password, saltRounds);

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).send({ message: 'User not found' });
          }
          
          user.fullName = fullName;
          user.password = hashedPassword;
          await user.save();
          
          res.send({ message: 'User updated successfully' });
          
    } catch (error) {
    res.status(500).send({ message: error.message });
    }
});
       

app.delete('/user/delete', async (req, res) => {
    const { email } = req.body;
    
    try {
    const result = await User.deleteOne({ email });
    if (result.deletedCount === 0) {
        return res.status(404).send({ message: 'User not found' });
      }
      
      res.send({ message: 'User deleted successfully' });
    } catch (error) {
        res.status(500).send({ message: error.message });
        }
});  


app.get('/user/getAll', async (req, res) => {
    try {
    const users = await User.find({}, { fullName: 1, email: 1, password: 1 });
    res.send(users);
    } catch (error) {
    res.status(500).send({ message: error.message });
    }
});
    

exports = module.exports = app;    
    
    
    
    
    
