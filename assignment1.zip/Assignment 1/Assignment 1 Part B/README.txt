This is a website for assignment 1 part B.
This is a nature blog website. "Serenity" is an wildlife and nature inspired blog and this is a basic html/css website.

In this website, there are 2 webpages:
-> 'index.html' which is the home webpage.
In this webpage, there are tags like header,footer,table,button,nav,div,link.
There is a CSS property used for BackgroundImage throughout the website.
There is an audio tag with the controls to refer to all the audios saved in the folder.

->'wildLife.html' which is the page to look at the videos of the blog.
This webpage consists of videos alongside it's controls based on wildlife.
The description is given with a font-family of fantasy and a standard of fonts is maintained throughout the website.

->'externalStyle.css' is an external Stylesheet used to style throughout the website.
This CSS file containes of styling done throughout the webpage using (asterix \*).
It includes styling done through class as well as id.
It also includes styling done through tags.
There is also @media included in order to provide screen flexibility.

This Website includes header and footer on everywebpage just to make the UI look good.
The header contains a logo text and a table that consists of two navigation links to the website. i.e. Nature and Wildlife. Note: The header nav links are designed to look like buttons but are in a table tag.
The footer consists of favIcons to connect to the social media platforms.
These icons are available in the  FavIcon lib of ajax following the link: 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'.


These audios, videos and images used in the website have been taken from a copyright free website from 'www.google.com'.

Tags used in this site are:
header
footer
table
audio
video
nav
anchor
BackgroundImage
FavIcon
@media in CSS