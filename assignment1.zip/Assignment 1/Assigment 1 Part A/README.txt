This is a website for assignment 1 part A.
This is a restaurant information website. "DineIn" is an indian cuisine restaurant and this is a basic html/css website.

In this website, there are 3 webpages:
-> 'index.html' which is the home webpage.
In this webpage, there are tags like header,footer,table,button,nav,div,link.
There is a CSS property used for BackgroundImage throughout the website.
There is a button for Know More that links to the AboutUs.html file which has hover CSS used at multiple places throughout the website.

->'aboutUs.html' which is the page to know about the restaurant.
This webpage consists of tags like form,header,footer,span,label,input.
The description is given with a font-family of fantasy and a standard of fonts is maintained throughout the website.
The form consists of the label of firstname and lastname where the inputs are taken from the user.
After clicking on submit to this form, the user will be redirected to 'thankYou.html'.

->'thankYou.html' is the last page of the website that can be used to submit the form print.
In this webpage, there are some icons for facebook,twitter,linkedin,youtube in order to make the restaurant socialy active.
these Icons arew taken from a FavIcon lib in ajax 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'.

->'external.css' is an external Stylesheet used to style throughout the website.
This CSS file containes of styling done throughout the webpage using (asterix \*).
It includes styling done through class as well as id.
It also includes styling done through tags.
This website follows a theme of fonts and colours throughout for better User Experience.

This Website includes header and footer on everywebpage just to make the UI look good.
The header contains a self-designed CSS logo and a table that consists of two navigation links to the website. i.e. Home and AboutUs. Note: The header nav links are designed to look like buttons but are in a table tag.
The footer consists of just a copyright word written.

The Images used in the website are used from a copyright free website from 'www.google.com'.

Tags Used In this Website are:

header
footer
table
nav
form
label
input
anchor HyperLink
FavIcon(title logo and the social media logo)
button
background Image



