import React from 'react';
import { useState } from 'react';
import {useNavigate} from 'react-router-dom';
import './Login.css';

export default function LoginPage({...props}){


  const navigate = useNavigate();

  const [userName, setUserName] = useState('');
  const [password, setPassword] = useState('');

  const handleSignIn = async (event) => {
    event.preventDefault();
    console.log(userName,"username");
    console.log(password,"password");
    const response = await fetch('http://localhost:8080/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userName, password })
    });
    console.log(response);
    if (response.ok) {
      // login successful, redirect to homepage
      console.log("login done");
      alert("Login Successful");
      console.log(props);
        props.handle();
        navigate('/main');
    } else {
      // login failed, display error message
      alert("Incorrect Username or Password");
    }
  }

    return(
        <div className='login-page'>
            <h1>Login</h1>
            <form onSubmit={handleSignIn}>
                <label>
                    Username:
                    <input type="text" className="login-input" value={userName} onChange={(e) => setUserName(e.target.value)}/>
                </label>
                <br/>
                <label>
                    Password:
                    <input type="password" className="login-input" value={password} onChange={(e) => setPassword(e.target.value)}/>
                </label>
                <br/>
                <button type="submit" className="login-button">Login</button>
            </form>
        </div>
    )


}