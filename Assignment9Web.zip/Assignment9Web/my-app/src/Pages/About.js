import React from "react";
import Card from '../Components/Cards/Card.js';

import '../Components/Cards/Card.css';
import './style.css';

function About(){
    const aboutPosts = [
        { title: 'Vision',description: 'Provide an important service to the world-instantly delivering relevant information on virtually any topic. ' },
        { title: 'Mission', description: 'Organize the worlds information and make it universally accessible and useful.' },
      ];
    return(
        <div className="wrapper">
            {aboutPosts.map((post) => (
            <Card
                    title={post.title}
                    image="https://mdbcdn.b-cdn.net/img/Photos/Horizontal/Nature/4-col/img%20(73).webp"
                    description={post.description}
            />
        ))}
        </div>
    )
}

export default About;