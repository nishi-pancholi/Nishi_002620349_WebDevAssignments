import React from "react";
import Card from '../Components/Cards/Card.js';
import '../Components/Cards/Card.css';
import './style.css';

function Home(){
    const homePosts = [
        { title: 'Company',description: 'Google LLC is an American multinational technology company focusing on online advertising, search engine technology.' },
        { title: 'History', description: 'Google was founded on September 4, 1998, by computer scientists Larry Page and Sergey Brin in California.' },
      ];
    return(
        <div className="wrapper">
            {homePosts.map((post) => (
            <Card
                    title={post.title}
                    image="https://mdbcdn.b-cdn.net/img/new/standard/nature/187.webp"
                    description={post.description}
            />
        ))}
        </div>
    )
}

export default Home;