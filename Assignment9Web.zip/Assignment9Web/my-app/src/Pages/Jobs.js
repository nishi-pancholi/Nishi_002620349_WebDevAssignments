import React from "react";
import Card from '../Components/Cards/Card.js';
import '../Components/Cards/Card.css';
import './style.css';

function Jobs(){
    const jobPosts = [
        { title: 'Software Developer',description: 'A software developer is a professional who designs, develops, and maintains software applications. ' },
        { title: 'Cloud Developer', description: 'A cloud developer is a software developer who specializes in creating and deploying applications.' },
      ];
    return(
        <div className="wrapper">
            {jobPosts.map((post) => (
            <Card
                    title={post.title}
                    image="https://mdbcdn.b-cdn.net/img/new/standard/nature/188.webp"
                    description={post.description}
            />
        ))}
        </div>
        
    )
}

export default Jobs;