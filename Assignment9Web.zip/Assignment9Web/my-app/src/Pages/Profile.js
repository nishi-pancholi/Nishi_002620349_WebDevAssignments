import React from "react";
import Card from '../Components/Cards/Card.js';
import '../Components/Cards/Card.css';
import './style.css';

function Profile(){
    const profilePosts = [
        { title: 'About Me',description: 'I am a software developer on MERN stack.' },
        { title: 'Experience', description: 'I have 4 years of experience' },
      ];
    return(
        <div className="wrapper">
            {profilePosts.map((post) => (
            <Card
                    title={post.title}
                    image="https://mdbcdn.b-cdn.net/img/new/standard/nature/181.webp"
                    description={post.description}
            />
        ))}
        </div>
    )
}

export default Profile;