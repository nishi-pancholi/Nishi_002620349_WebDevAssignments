const model = require('../models/model.js');

const service = {
  findUser: async (userName, password) => {
    const user = await model.findOne({ userName });
    console.log(user,"user");
    if (!user) throw new Error('Incorrect username or password');
    return user;
  },
};

module.exports = service;
