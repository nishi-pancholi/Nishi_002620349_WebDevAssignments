const controller = require('../controllers/controller.js');
console.log("router called");


module.exports = function (app) {
    app.post('/api/login', controller.login);
};
