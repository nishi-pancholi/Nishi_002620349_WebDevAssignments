const service = require('../services/service.js');
console.log("controller called");
exports.login = async (req, res) => {
  console.log(req.body);
  try {
    const { userName, password } = req.body;
    const user = await service.findUser( req.body.userName , req.body.password);

    if (!user) {
      return res.status(400).json({ message: "User not found." });
    }

    if (user.password !== password) {
      return res.status(400).json({ message: "Incorrect password." });
    }

    res.status(200).json({ message: "Login successful." });
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Server error." });
  }
};

