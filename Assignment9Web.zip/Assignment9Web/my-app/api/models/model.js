var mongoose = require("mongoose");


const UserSchema = new mongoose.Schema({
  userName: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [8, 'Password must be at least 8 characters long']
  }
});

module.exports = mongoose.model('mdUsers', UserSchema);
