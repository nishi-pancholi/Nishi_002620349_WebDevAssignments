This React Application has a two parts the client-side and the server-side.

The client-side application is based on React where there is one entry point which is the Login page.
On a successfull login the user is redirected to the Main page which has a navigations of the links to different pages inside the pages folder.

Client-side folder structure includes(src):
Components : Here, there is a reusable Component created for the cards which are used in different pages.
img: This folder includes all the img used
Login: This consists of the Login Page code
Main: This consists of the main page code.
Pages: This includes various pages like home,about,job,profile. All these pages include the react Card Component with react.map().

The server-side application is used to check whether the correct user is able to access the application.
The login Page will call the router api which then handles the login.

Server-side folder structure includes(api):
Routes: This is the main call where the routing happens, which calls the controller for login function.
Controllers: This has a function defined to handle the login which uses a service to find the user.
Services: This includees the service where the User model is called to find the user.
Models: This includes a DB scehema

The entry point to the backend server-side is server.js which has the setups and connections to db.
