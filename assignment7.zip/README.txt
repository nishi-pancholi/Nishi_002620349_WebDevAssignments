This is a restaurant information website. "DineIn" is an indian cuisine restaurant and this is a basic html/css website.

In this website, there are 3 webpages:
-> 'index.html' which is the home webpage.
->'aboutUs.html' which is the page to know about the restaurant.
->'thankYou.html' is the last page of the website that can be used to submit the form print.


->external.scss is the file where the scss is generates through which external.css is generated which is then linked to the html page.


Assignment requirements:

CSS Grid Layout: 
All the 3 pages are designed inside s grid-container.
This includes 3 rows one for header, one for footer and one for content throughout the webpages.

CSS Flexbox:
The CSS flexbox is implemented inside the thankyou.html page where the icons for contacting are present.
These icons are inside a flex container.

SASS/SCSS properties:

Variables:
Variables are declared inside _variables.scss which are then imported throughout the scss folder.

Custom Poperties:
They are used for transitioning throughout the website.
--transitionTime is the cusyom property created to store the transition time which is then implemted using the transition using var().

Nesting:
.content class is nested using scss to store all the styling of the content rhoughout the website.
Multiple tags are stored inside this nesting feature.

Interpolation & mixin:
this code is stored inside _functions.scss which then is used to change the poperty and it's value based on each call.
Demo of this call can be seen inside _home.scss.

Functions:
Function are saved inside _functions.scss in order to access it throughout the scss file when imported. 
Function set-px-ten sets the px value to any number multiplied by ten similar as to  the h1,h1,h6 tag of html for font sizes, this custom function works for pixels.

PlaceHolder Selectors:
Placeholder selector is used inside _buttons.scss to sset the design of the button which can be used throughout the website.
These is then extended inside the external.scss file.


Multiple files created for multiple features are:

_Variables: to store the Variables
_home: to store the design of home page
_aboutUs: to store design of about us page
_config: to store the main config css 
_buttons: to store the button design 
_faicons: to store the design of the icons sued in order to connect e.g facebook, insta, linked in etc
_functions: to store multiple used functions across the scss folder
_gridFlex: to store design of CSS Grid and Flexbox

external.scss is the main scss file.



